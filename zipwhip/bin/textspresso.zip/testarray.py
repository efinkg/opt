from array import *
#global a
a = [10, 20, 30, 40]
#print a
#global indx
indx = [3, 5, 9]
data = []
#for e in a:
#	print e

def method():
	#global indx
	#print a
	print data
	for e in a:
		print e
	for e in indx:
		print e
		
method()
